﻿using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;

namespace MarkaKod.API.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class RouteController : ControllerBase
    {
        private List<Location> list = new List<Location>()
        {
            new Location() { Title = "Location A", Lat = 40.994152, Long = 29.060207 },
            new Location() { Title = "Location B", Lat = 41.086795, Long = 29.084657 },
            new Location() { Title = "Location C", Lat = 41.045335, Long = 28.975234 },
            new Location() { Title = "Location D", Lat = 41.120088, Long = 29.036362, CurrentLocation = true },
            new Location() { Title = "Location E", Lat = 41.006318, Long = 28.93529 },
            new Location() { Title = "Location F", Lat = 41.263104, Long = 28.288908 },
            new Location() { Title = "Location G", Lat = 41.05016, Long = 29.486747 }
        };

        [HttpGet]
        [Route("Get")]
        public IEnumerable<Location> GetList()
        {
            return list;
        }

        [Route("GetCalculatedLocations")]
        [HttpGet]
        public IEnumerable<Location> GetCalculatedLocations( )
        {
            var currentLocaiton = list.FirstOrDefault(x => x.CurrentLocation && !x.Visited);

            if (currentLocaiton == null)
            {
                currentLocaiton = list.FirstOrDefault(x => !x.Visited);
                currentLocaiton.Km = 0;
            }

            var notVisitedList = list.Where(x => !x.Visited && x.Title != currentLocaiton.Title).ToList();

            foreach (var location in notVisitedList)
            {
                location.Km = Distance.CalculateDistance(currentLocaiton.Lat, currentLocaiton.Long, location.Lat, location.Long);
                location.CurrentLocation = false;
            }

            notVisitedList.Add(currentLocaiton);

            return notVisitedList.OrderBy(x => x.Km);





        }
    }
}
