﻿namespace MarkaKod.API
{
    public class Location
    {
        public string Title { get; set; }
        public double Lat { get; set; }
        public double Long { get; set; }
        public bool CurrentLocation { get; set; } = false;
        public bool Visited { get; set; } = false;
        public double Km { get; set; }

    }
}
